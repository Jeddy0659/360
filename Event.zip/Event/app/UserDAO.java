public class UserDAO {
}
package com.example.loginapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase

class UserDAO(context: Context) {

    private val dbHelper = DBHelper(context)
    private var db: SQLiteDatabase? = null

    fun open() {
        db = dbHelper.writableDatabase
    }

    fun close() {
        dbHelper.close()
    }

    // Validate user login
    fun validateLogin(username: String, password: String): Boolean {
        val columns = arrayOf(DBHelper.COLUMN_USERNAME)
        val selection = "${DBHelper.COLUMN_USERNAME}=? AND ${DBHelper.COLUMN_PASSWORD}=?"
        val selectionArgs = arrayOf(username, password)

        val cursor: Cursor = db?.query(
                DBHelper.TABLE_USERS, columns, selection, selectionArgs,
                null, null, null
        ) ?: throw SQLException("Failed to query the database.")

        val cursorCount = cursor.count
        cursor.close()
        return cursorCount > 0
    }

    // Insert a new user into the database
    fun insertUser(username: String, password: String): Long {
        val values = ContentValues().apply {
            put(DBHelper.COLUMN_USERNAME, username)
            put(DBHelper.COLUMN_PASSWORD, password)
        }
        return db?.insert(DBHelper.TABLE_USERS, null, values) ?: -1
    }
}

