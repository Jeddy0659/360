package com.example.event

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.event.ui.theme.EventTheme

class MainActivity : ComponentActivity() {
    private lateinit var eventDAO: EventDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        eventDAO = EventDAO(this)
        eventDAO.open()

        setContent {
            EventAppUI(eventDAO)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        eventDAO.close()
    }
}

@Composable
fun EventAppUI(eventDAO: EventDAO) {
    // State variables to hold event details from text fields
    var eventName by remember { mutableStateOf("") }
    var eventDate by remember { mutableStateOf("") }
    var eventDescription by remember { mutableStateOf("") }

    // List of events to display in LazyColumn
    val events by remember { mutableStateOf(eventDAO.getAllEvents()) }

    // Main layout for the app
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Add New Event", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(16.dp))

        // Event Name TextField
        BasicTextField(
            value = eventName,
            onValueChange = { eventName = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            decorationBox = { innerTextField ->
                if (eventName.isEmpty()) {
                    Text("Enter event name", style = MaterialTheme.typography.bodyLarge)
                }
                innerTextField()
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Event Date TextField
        BasicTextField(
            value = eventDate,
            onValueChange = { eventDate = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            decorationBox = { innerTextField ->
                if (eventDate.isEmpty()) {
                    Text("Enter event date", style = MaterialTheme.typography.bodyLarge)
                }
                innerTextField()
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Event Description TextField
        BasicTextField(
            value = eventDescription,
            onValueChange = { eventDescription = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            decorationBox = { innerTextField ->
                if (eventDescription.isEmpty()) {
                    Text("Enter event description", style = MaterialTheme.typography.bodyLarge)
                }
                innerTextField()
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Add Event Button
        Button(onClick = {
            if (eventName.isNotEmpty() && eventDate.isNotEmpty() && eventDescription.isNotEmpty()) {
                eventDAO.insertEvent(eventName, eventDate, eventDescription)
            } else {
                Toast.makeText(this@MainActivity, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }) {
            Text("Add Event")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Display events in a grid-like structure (LazyColumn)
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(events.size) { index ->
                val event = events[index]
                Text("${event.name} on ${event.date}", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    EventTheme {
        // Mock EventDAO for preview
        val mockDAO = EventDAO(LocalContext.current)
        EventAppUI(mockDAO)
    }
}

// Mock DAO (replace this with actual database code)
class EventDAO(context: Context) {
    private val eventList = mutableListOf<Event>()

    // Open database (for mock purposes)
    fun open() {}

    // Close database (for mock purposes)
    fun close() {}

    // Insert a new event (mock implementation)
    fun insertEvent(name: String, date: String, description: String) {
        val event = Event(name, date, description)
        eventList.add(event)
    }

    // Get all events (mock implementation)
    fun getAllEvents(): List<Event> {
        return eventList
    }
}

// Data model class for Event
data class Event(val name: String, val date: String, val description: String)

}